export const environment = {
    production: true,
 
    // apiUrl: "http://localhost:9090/"
    apiUrl: "http://68.183.80.59:8080/g10services/"

};
