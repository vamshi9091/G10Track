import { Component } from '@angular/core';

@Component({
  selector: 'app-dashboardtheme',
  templateUrl: './dashboardtheme.component.html',
  styleUrls: ['./dashboardtheme.component.css']
})
export class DashboardthemeComponent {

}
