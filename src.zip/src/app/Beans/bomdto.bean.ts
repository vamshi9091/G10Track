export class BomDto {
    id: number = 0;
    item: string = '';
    description: string = '';
    quantity: number = 0;

    // "item": "item",
    // "description": "description",
    // "quantity": 123
}