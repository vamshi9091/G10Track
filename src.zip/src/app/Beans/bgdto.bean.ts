export class BgDto {
    id: number = 0;
    bgNumber: string = '';
    IssueDate!: Date;
    clearDate!: Date;
}

