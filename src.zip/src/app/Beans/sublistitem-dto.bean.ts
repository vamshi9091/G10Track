export class SubListItemDto {
    id: number = 0;
    listItem: string = '';
    subListItem: string = '';
    status: string = '';
  }

