export class UserChange {
   
    userName: string = '';
    password: string = '';
    confirmPassword:string=''
}
