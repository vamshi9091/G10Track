export class Employee {
    empid: number = 0;
    name: string = '';
    doj!: Date;
    designation: string = '';
    imageData: string='';
}