export class UserDeptDto {

	id: number = 0;
	deptName: string = '';
	address: string = '';
	state: string = '';
	country: string = '';
  selectedEmployee: any;

}