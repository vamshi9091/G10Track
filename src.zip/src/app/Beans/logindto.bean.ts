export class Loginauth {
    userName: string = '';
    password: string = '';
}
