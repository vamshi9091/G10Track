
export class SystemListDto {
    id: number = 0;
    name: string = '';
    status: string = '';
    // listItemDto:
  }