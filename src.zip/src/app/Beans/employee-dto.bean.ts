export class EmployeeDto {
    empid: number = 0;
    name: string = '';
    doj: string ='';
    designation: string = '';
    emaiid:string ='';
    phoneNum:string ='';
    imageData: string = ''; 
    role: string = ''; 
}