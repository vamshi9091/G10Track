export class NotesDto {
	id: number = 0;
	loggedBy: string = '';
	loggedTime!: Date;
	note: string = '';
}