export class ListItemDto {
    id: number = 0;
    listName: string = '';
    listItem: string = '';
    status: string = '';
  }