export class DdDto {
    id: number = 0;
    issueDate!: Date;
    clearDate!: Date;
    bankName: string = '';
    
}