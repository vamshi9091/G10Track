export class OnlineDto {
    id: number = 0;
    bankName: string = '';
    transactionNo: string = '';
}