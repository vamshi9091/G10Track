export enum Role  {
    ROLE_USER= 'ROLE_USER',
     AdminSale= 'AdminSale'
  };